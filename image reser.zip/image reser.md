```python
from PIL import Image,ImageFilter
img=Image.open('code.png')
img
```




    
![png](output_0_0.png)
    




```python
from PIL import Image,ImageFilter
img=Image.open('kohli.png')
img
```




    
![png](output_1_0.png)
    




```python
from PIL import Image,ImageFilter
img=Image.open('sameer.png')
img = img.resize((400, 400))
img
```




    
![png](output_2_0.png)
    




```python
from PIL import Image, ImageFilter
img=Image.open("srimanth.png")
img= img.resize((400,300))
img.save
```




    <bound method Image.save of <PIL.Image.Image image mode=RGBA size=400x300 at 0x146C8FE0F70>>




```python
from PIL import Image, ImageFilter
img=Image.open("srimanth.png")
img= img.resize((400,300))
img
```




    
![png](output_4_0.png)
    




```python
from PIL import Image,ImageFilter
img=Image.open('code.png')
img=img.resize((400,300))
img.save
```




    <bound method Image.save of <PIL.Image.Image image mode=RGBA size=400x300 at 0x146C930BBB0>>




```python
dir
```




    <function dir>




```python

```
